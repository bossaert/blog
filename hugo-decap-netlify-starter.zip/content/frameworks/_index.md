---
title: "Frameworks"
---
- **Portfolio Health and Client Checkup** - a practical scoring model for advisors and marketing.
- **Planning Knowledge Graph** - how unstructured inputs become structured strategies.
- **Unified Wealth Operating Model** - CRM, portfolio, rebalancing, and planning linkages.
- **AI Engagement Ladder** - from detection to advisor action and client outcomes.
