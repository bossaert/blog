---
title: "About"
description: "About this site"
---
I help leaders in investment and wealth management make forward-looking decisions. My work focuses on buyer demand, product and portfolio innovation, operating models, and the impact of data and AI. I translate complex markets into clear frameworks, exhibits, and executive narratives that drive action.

Previously, I led platforms and planning capabilities across banks, RIAs, and fintech, integrating CRM, portfolio accounting, rebalancing, and tax-aware planning at scale. I am a CFP with an MS in Personal Financial Planning.

Opinions are my own. This site is for research and education, not investment advice.
