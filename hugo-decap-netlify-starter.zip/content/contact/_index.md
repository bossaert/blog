---
title: "Contact"
---
For speaking, media, or project inquiries: <your@email> and LinkedIn <your-URL>. Submissions and comments are welcome.
