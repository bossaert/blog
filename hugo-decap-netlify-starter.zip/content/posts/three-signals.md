---
title: "Three signals I am watching this quarter"
date: 2025-09-13
description: "Quick take on near-term signals that matter for leaders in wealth and investment management."
tags: ["buyer-demand", "product-innovation"]
---
- **Packaging of direct indexing and tax-aware tools** in model marketplaces and how that reshapes pricing power.  
- **Guardrail adoption in retiree workflows** and whether it reduces service spikes after drawdowns.  
- **Advisor AI usage patterns** that move from chat to structured actions with measurable client outcomes.
